 <a href="query.php">Pick another query</a>

 <?php
       //Query to get the GDP
        $sql = "select name, gdp from countrydata_final;";
        $conn = new mysqli($_SESSION['ep'], $_SESSION['un'], $_SESSION['pw'], $_SESSION['db']);
        //$conn = new mysqli('localhost','db_user','Pa$$w0rd','country_schema');

        if ($conn->connect_error) {
            error_log('Connection error: ' . $conn->connect_error);
            var_dump('Connection error: ' . $conn->connect_error);
        echo 'Fail to connect Database!';
        }
        else {
          $result = $conn->query($sql);
                $str_rows = $result->num_rows;

if ($result && $result->num_rows>0){
          if ($result->num_rows > 0) {

              echo '<table style="width: 80%">';
              echo '<tr>';
              echo '<th style="text-align:left">This is a Country Name</th>';
              echo '<th style="text-align:left">Gross Domestic Product</th>';
              echo '</tr>';

              while($row = $result->fetch_assoc()) {

              echo '<tr>';
              echo '<td>';
              echo $row["name"];
              echo '&nbsp';
              echo '<td>';
              echo $row["gdp"];
              echo '&nbsp';
              echo '<br>';
              echo '</tr>';
              }
              echo '</table>';
            }
}else{
 if ($result === false) {
        // The query failed, log the error
        error_log('Query error: ' . $conn->error);
        echo 'Query error: ' . $conn->error;
    } else {
        // The query executed but returned no rows
        echo 'No rows returned from the query.';
	}
    }
}

?>
