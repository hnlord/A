<?php
  # Retrieve settings from Parameter Store
  error_log('Retrieving settings');
  require 'aws.phar';
  session_start();

  $TOKEN= trim(`curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600"`) ;
  $region=trim(`curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone`);
  $az=$region;
  $region = substr($region, 0, -1);
  $ssm_client = new Aws\Ssm\SsmClient([
     'version' => 'latest',
     'region'  => $region   	
  ]);

  try {
    # Retrieve settings from Parameter Store
    $result = $ssm_client->GetParametersByPath(['Path' => '/example/', 'WithDecryption' => true]);    

    # Extract individual parameters
    foreach($result['Parameters'] as $p) {
        $values[$p['Name']] = $p['Value'];
    }

    $_SESSION['ep'] = $values['/example/endpoint'];
    $_SESSION['un'] = $values['/example/username'];
    $_SESSION['pw'] = $values['/example/password'];
    $_SESSION['db'] = $values['/example/database'];
  }
  catch (Exception $e) {
    error_log('Error retrieving settings: ' . $e->getMessage());
    echo "An error occurred while retrieving settings.";
    $_SESSION['ep'] = '';
    $_SESSION['un'] = '';
    $_SESSION['pw'] = '';
    $_SESSION['db'] = '';
  }

?>