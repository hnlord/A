<?php
  # Retrieve settings from Parameter Store
  error_log('Retrieving settings');
  require 'aws.phar';
  session_start();

  //$az = file_get_contents('http://169.254.169.254/latest/meta-data/placement/availability-zone');
  //$region = substr($az, 0, -1);
  $ssm_client = new Aws\Ssm\SsmClient([
     'version' => 'latest',
     'region'  => 'us-east-1'   	
  ]);

  try {
    # Retrieve settings from Parameter Store
    //$result = $ssm_client->GetParametersByPath(['Path' => '/example/', 'WithDecryption' => true]);
    $result = $ssm_client->GetParameters(['Names' => ['/example/endpoint','/example/username','/example/password','/example/database']]);

    # Extract individual parameters
    foreach($result['Parameters'] as $p) {
        $values[$p['Name']] = $p['Value'];
    }

    $_SESSION['ep'] = $values['/example/endpoint'];
    $_SESSION['un'] = $values['/example/username'];
    $_SESSION['pw'] = $values['/example/password'];
    $_SESSION['db'] = $values['/example/database'];
    //echo $_SESSION['db'];
  }
  catch (Exception $e) {
    error_log('Error retrieving settings: ' . $e->getMessage());
    echo "An error occurred while retrieving settings.";
    $_SESSION['ep'] = '';
    $_SESSION['un'] = '';
    $_SESSION['pw'] = '';
    $_SESSION['db'] = '';
  }

?>